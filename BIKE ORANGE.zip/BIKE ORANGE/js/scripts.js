
document.addEventListener("DOMContentLoaded", () => {
    const rutaForm = document.getElementById("ruta-form");
    if (rutaForm) {
        rutaForm.addEventListener("submit", function(e) {
            e.preventDefault();
            const lugar = document.getElementById("lugar").value;
            alert(`Ruta creada desde ${lugar}!`);
        });
    }
});
